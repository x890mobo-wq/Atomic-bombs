#!/usr/bin/env bash
# Atomic Bombs - export an Android APK from the command line (Linux / macOS / Git-Bash / WSL).
#
# Needs (once):
#   * Godot 4.7.2 + its export templates   (Editor > Manage Export Templates > Download)
#   * JDK 17                               (java -version)
#   * Android SDK with platform-tools, build-tools;35.0.1, platforms;android-35
#   * Godot > Editor Settings > Export > Android: set "Android SDK Path" and "Java SDK Path"
#
# Usage:  GODOT=/path/to/godot ./build_android.sh
set -euo pipefail
cd "$(dirname "$0")"
GODOT="${GODOT:-godot}"

KS="${KEYSTORE:-$PWD/atomic-release.keystore}"
if [ ! -f "$KS" ]; then
  echo "Creating a signing key: $KS (keep it, a phone only accepts updates signed with the same key)"
  keytool -genkeypair -v -keystore "$KS" -alias atomic -keyalg RSA -keysize 2048 -validity 10000 \
    -storepass atomic-bombs -keypass atomic-bombs -dname "CN=Atomic Bombs, O=Opus 5.5, C=US"
fi
export GODOT_ANDROID_KEYSTORE_RELEASE_PATH="$KS"
export GODOT_ANDROID_KEYSTORE_RELEASE_USER="atomic"
export GODOT_ANDROID_KEYSTORE_RELEASE_PASSWORD="atomic-bombs"

mkdir -p build
"$GODOT" --headless --path . --import || true
"$GODOT" --headless --path . --export-release "Android" build/AtomicBombs.apk
echo "DONE: $PWD/build/AtomicBombs.apk"
echo "Install:  adb install -r build/AtomicBombs.apk   (or copy the file to the phone and open it)"
