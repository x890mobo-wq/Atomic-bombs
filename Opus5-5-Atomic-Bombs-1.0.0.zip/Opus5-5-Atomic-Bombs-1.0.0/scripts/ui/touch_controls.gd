extends CanvasLayer
## On-screen controls for phones and tablets (Android port).
##
##   * one finger on the empty screen   = look around (PlayerCamera.touch_look)
##   * two fingers                      = pinch to zoom the binoculars (PlayerCamera.touch_zoom)
##   * MENU / PAUSE / CAM / MORE        = always-visible buttons, top right
##   * MORE opens: slower, faster, reset, time of day, humidity, HUD, zoom +/-, camera angles 1-4
##   * in free-camera mode (CAM) a fly stick appears bottom left, UP / DN / FAST bottom right
##
## Every button just sends the same key the desktop version uses (Tab, Space, C, R, T, H, F1, 1-4,
## [ and ]), so main.gd and the UI need no touch-specific logic besides this node.
## The whole layer hides itself while the menu, the quit dialog or the "bunker destroyed" screen
## is open (PlayerCamera.look_enabled is false then), and the Android Back button is mapped to Esc
## in main.gd.

const UiTheme = preload("res://scripts/ui/ui_theme.gd")

const BTN_W := 112.0
const BTN_H := 62.0
const GAP := 8.0
const MARGIN := 14.0
const STICK_R := 118.0
const STICK_MARGIN := 36.0
const FONT := 22


## The fly stick: a ring and a knob. Purely visual; touches are handled by the layer's _input.
class StickPad extends Control:
	var vec := Vector2.ZERO

	func _draw() -> void:
		var c := size * 0.5
		var r := minf(size.x, size.y) * 0.5
		draw_circle(c, r, Color(0.02, 0.08, 0.04, 0.35))
		draw_arc(c, r - 2.0, 0.0, TAU, 48, Color(0.45, 1.0, 0.58, 0.55), 3.0, true)
		draw_circle(c + vec * (r * 0.62), r * 0.3, Color(0.45, 1.0, 0.58, 0.5))


var cam: PlayerCamera
var ui: Node

var _root: Control
var _top: Array[Button] = []          # MENU, PAUSE, CAM, MORE
var _more: Array[Button] = []         # the MORE panel (12 buttons, 4 per row)
var _fly: Array[Button] = []          # UP, DN, FAST (free camera only)
var _all: Array[Button] = []
var _txt: Dictionary = {}             # Button -> [russian, english]
var _more_open := false
var _pause_btn: Button
var _was_paused := false
var _stick: StickPad
var _stick_finger := -1
var _stick_vec := Vector2.ZERO
var _alt := 0.0
var _look: Dictionary = {}            # finger index -> last position (fingers that look / pinch)
var _pinch_prev := 0.0


## Sends a key press + release through the normal input pipeline.
static func press_key(keycode: Key) -> void:
	for down in [true, false]:
		var ev := InputEventKey.new()
		ev.keycode = keycode
		ev.physical_keycode = keycode
		ev.pressed = down
		Input.parse_input_event(ev)


func _init() -> void:
	name = "Touch"
	layer = 15
	process_mode = Node.PROCESS_MODE_ALWAYS


func setup(p_cam: PlayerCamera, p_ui: Node) -> void:
	cam = p_cam
	ui = p_ui
	_build()
	cam.mode_changed.connect(_on_cine_changed)
	Game.language_changed.connect(_retranslate)
	get_viewport().size_changed.connect(_layout)
	_retranslate()
	_apply_visibility()
	_layout()


# ------------------------------------------------------------------ building

func _build() -> void:
	_root = Control.new()
	_root.name = "Root"
	_root.mouse_filter = Control.MOUSE_FILTER_IGNORE
	_root.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	_root.theme = UiTheme.get_theme()
	add_child(_root)

	_key_btn(["МЕНЮ", "MENU"], KEY_TAB, _top)
	_pause_btn = _key_btn(["ПАУЗА", "PAUSE"], KEY_SPACE, _top)
	_key_btn(["КАМЕРА", "CAM"], KEY_C, _top)
	var more_btn := _btn(["ЕЩЁ", "MORE"], _top)
	more_btn.pressed.connect(_toggle_more)

	_key_btn(["<<", "<<"], KEY_BRACKETLEFT, _more)
	_key_btn([">>", ">>"], KEY_BRACKETRIGHT, _more)
	_key_btn(["СБРОС", "RESET"], KEY_R, _more)
	_key_btn(["ВРЕМЯ", "TIME"], KEY_T, _more)
	_key_btn(["ВЛАЖН", "HUMID"], KEY_H, _more)
	_key_btn(["HUD", "HUD"], KEY_F1, _more)
	var zin := _btn(["ЗУМ +", "ZOOM +"], _more)
	zin.pressed.connect(func() -> void: cam.zoom_step(true))
	var zout := _btn(["ЗУМ -", "ZOOM -"], _more)
	zout.pressed.connect(func() -> void: cam.zoom_step(false))
	_key_btn(["1", "1"], KEY_1, _more)
	_key_btn(["2", "2"], KEY_2, _more)
	_key_btn(["3", "3"], KEY_3, _more)
	_key_btn(["4", "4"], KEY_4, _more)

	var up := _btn(["ВВЕРХ", "UP"], _fly)
	up.button_down.connect(func() -> void: _alt = 1.0)
	up.button_up.connect(func() -> void: _alt = 0.0)
	var dn := _btn(["ВНИЗ", "DOWN"], _fly)
	dn.button_down.connect(func() -> void: _alt = -1.0)
	dn.button_up.connect(func() -> void: _alt = 0.0)
	var fast := _btn(["БЫСТРО", "FAST"], _fly)
	fast.toggle_mode = true
	fast.toggled.connect(func(on: bool) -> void: cam.touch_fast = on)

	_stick = StickPad.new()
	_stick.name = "Stick"
	_stick.mouse_filter = Control.MOUSE_FILTER_IGNORE
	_stick.size = Vector2(STICK_R * 2.0, STICK_R * 2.0)
	_root.add_child(_stick)


func _btn(labels: Array, group: Array[Button]) -> Button:
	var b := Button.new()
	b.focus_mode = Control.FOCUS_NONE
	b.custom_minimum_size = Vector2(BTN_W, BTN_H)
	b.size = b.custom_minimum_size
	b.clip_text = true
	b.add_theme_font_size_override("font_size", FONT)
	_root.add_child(b)
	group.append(b)
	_all.append(b)
	_txt[b] = labels
	return b


func _key_btn(labels: Array, keycode: Key, group: Array[Button]) -> Button:
	var b := _btn(labels, group)
	b.pressed.connect(func() -> void: press_key(keycode))
	return b


# ------------------------------------------------------------------ layout / state

func _safe_insets(k: float) -> Vector4:
	# display cut-out / gesture bar, in virtual (scaled) pixels; (left, top, right, bottom)
	var sa := DisplayServer.get_display_safe_area()
	var ws := DisplayServer.window_get_size()
	if sa.size.x <= 0 or sa.size.y <= 0 or ws.x <= 0 or ws.y <= 0:
		return Vector4.ZERO
	var l := maxf(float(sa.position.x), 0.0)
	var t := maxf(float(sa.position.y), 0.0)
	var r := maxf(float(ws.x - sa.end.x), 0.0)
	var b := maxf(float(ws.y - sa.end.y), 0.0)
	var v := Vector4(l, t, r, b) / maxf(k, 0.01)
	return Vector4(minf(v.x, 120.0), minf(v.y, 120.0), minf(v.z, 120.0), minf(v.w, 120.0))


func _layout() -> void:
	if _root == null:
		return
	var vs := get_viewport().get_visible_rect().size
	var ins := _safe_insets(get_window().content_scale_factor)
	var right := vs.x - ins.z - MARGIN
	var left := ins.x + MARGIN
	var top := ins.y + MARGIN
	var bottom := vs.y - ins.w - MARGIN

	# top row, right aligned
	var x := right
	for i in range(_top.size() - 1, -1, -1):
		x -= BTN_W
		_top[i].position = Vector2(x, top)
		x -= GAP

	# MORE panel: 4 columns under the top row, right aligned
	var cols := 4
	for i in _more.size():
		var col := i % cols
		var row := floori(float(i) / float(cols))
		var px := right - float(cols - col) * BTN_W - float(cols - col - 1) * GAP
		var py := top + BTN_H + GAP + float(row) * (BTN_H + GAP)
		_more[i].position = Vector2(px, py)

	# free-camera controls
	for i in _fly.size():
		_fly[i].position = Vector2(right - BTN_W, bottom - float(_fly.size() - i) * BTN_H - float(_fly.size() - i - 1) * GAP)
	_stick.position = Vector2(left + STICK_MARGIN, bottom - STICK_R * 2.0 - STICK_MARGIN * 0.5)


func _toggle_more() -> void:
	_more_open = not _more_open
	_apply_visibility()
	_layout()


func _apply_visibility() -> void:
	var fly := cam != null and cam.cine
	for b in _more:
		b.visible = _more_open
	for b in _fly:
		b.visible = fly
	if _stick:
		_stick.visible = fly
	if not fly:
		_stick_finger = -1
		_stick_vec = Vector2.ZERO
		_alt = 0.0
		if _stick:
			_stick.vec = Vector2.ZERO
			_stick.queue_redraw()


func _on_cine_changed(_cine: bool) -> void:
	_apply_visibility()


func _retranslate() -> void:
	var i := 0 if Game.lang == "ru" else 1
	for b in _txt:
		(b as Button).text = String((_txt[b] as Array)[i])
	_was_paused = not Game.paused     # force the pause label to refresh
	_refresh_pause_label()


func _refresh_pause_label() -> void:
	if Game.paused == _was_paused:
		return
	_was_paused = Game.paused
	var ru := Game.lang == "ru"
	_pause_btn.text = ("ПУСК" if ru else "RESUME") if _was_paused else ("ПАУЗА" if ru else "PAUSE")


func _process(_delta: float) -> void:
	if cam == null:
		return
	var on := cam.look_enabled
	if visible != on:
		visible = on
		if not on:
			_release_all()
	_refresh_pause_label()
	cam.touch_move = Vector3(_stick_vec.x, _alt, -_stick_vec.y) if cam.cine else Vector3.ZERO


func _release_all() -> void:
	_look.clear()
	_pinch_prev = 0.0
	_stick_finger = -1
	_stick_vec = Vector2.ZERO
	_alt = 0.0
	if _stick:
		_stick.vec = Vector2.ZERO
		_stick.queue_redraw()


# ------------------------------------------------------------------ raw touch (look / pinch / stick)

func _input(event: InputEvent) -> void:
	if get_viewport().is_input_handled():
		return
	if event is InputEventScreenTouch:
		var t := event as InputEventScreenTouch
		if not t.pressed:
			_finger_up(t.index)
		elif visible:
			_finger_down(t.index, t.position)
	elif event is InputEventScreenDrag:
		var d := event as InputEventScreenDrag
		_finger_move(d.index, d.position, d.relative)


func _over_ui(pos: Vector2) -> bool:
	# any visible GUI control under the finger (our buttons or the game's menus / dialogs)
	var hit := get_viewport().gui_get_hovered_control() if get_viewport().has_method("gui_get_hovered_control") else null
	if hit != null and hit.is_visible_in_tree():
		return true
	for b in _all:
		if b.is_visible_in_tree() and b.get_global_rect().grow(6.0).has_point(pos):
			return true
	return false


func _stick_center() -> Vector2:
	return _stick.get_global_rect().get_center()


func _finger_down(idx: int, pos: Vector2) -> void:
	if _stick.visible and _stick_finger < 0 and pos.distance_to(_stick_center()) < STICK_R * 1.35:
		_stick_finger = idx
		_stick_set(pos)
	elif not _over_ui(pos):
		_look[idx] = pos
		_pinch_prev = 0.0
	else:
		_look.erase(idx)


func _finger_move(idx: int, pos: Vector2, rel: Vector2) -> void:
	if idx == _stick_finger:
		_stick_set(pos)
	elif _look.has(idx):
		_look[idx] = pos
		if _look.size() == 1:
			var h := maxf(get_viewport().get_visible_rect().size.y, 1.0)
			cam.touch_look(rel / h)
		else:
			_pinch()


func _finger_up(idx: int) -> void:
	if idx == _stick_finger:
		_stick_finger = -1
		_stick_vec = Vector2.ZERO
		_stick.vec = Vector2.ZERO
		_stick.queue_redraw()
	_look.erase(idx)
	_pinch_prev = 0.0


func _stick_set(pos: Vector2) -> void:
	_stick_vec = ((pos - _stick_center()) / STICK_R).limit_length(1.0)
	_stick.vec = _stick_vec
	_stick.queue_redraw()


func _pinch() -> void:
	var keys := _look.keys()
	if keys.size() < 2:
		return
	var d := (_look[keys[0]] as Vector2).distance_to(_look[keys[1]] as Vector2)
	if _pinch_prev > 8.0 and d > 8.0:
		cam.touch_zoom(_pinch_prev / d)
	_pinch_prev = d
