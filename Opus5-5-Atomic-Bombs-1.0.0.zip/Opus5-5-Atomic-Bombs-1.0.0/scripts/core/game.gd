extends Node
## Global state and settings (autoload "Game").

signal settings_changed
signal language_changed
signal bomb_selected(index: int)

enum Quality { LOW, MEDIUM, HIGH, CINEMATIC }
## PREDAWN (sun ~5 deg below the horizon) is a historical preset (Trinity 05:29, Castle Bravo); the
## T key and the menu cycle the first four.
enum TimeOfDay { DAWN, NOON, DUSK, NIGHT, PREDAWN }

const TOD_NAMES := ["dawn", "noon", "dusk", "night", "predawn"]
const QUALITY_NAMES := ["low", "medium", "high", "cine"]

var bombs: Array = []              # parsed data/bombs.json "bombs"
var locale: Dictionary = {}        # parsed data/locale.json
var lang := "ru"

var selected_bomb := 10            # 0-based index
var distance_km := 25.0
var azimuth_deg := 0.0
var tod: int = TimeOfDay.NOON
var humidity := 0.35              # dry desert default (Wilson clouds need humid presets)
var humidity_manual := false      # true once the player picks a humidity (H key / menu): no site default
var quality: int = Quality.HIGH
var auto_quality := true
var time_scale := 1.0
var paused := false
var hud_visible := true
var film_grain := true
var high_clouds := true
var snow_override := -1            # -1 auto (per bomb), 0 off, 1 on

var is_movie := false
var is_test_rig := false

## Phone / tablet build (Android, iOS) or `-- --touch` on a desktop for testing the touch UI.
var is_touch := false
## Extra scale of the whole 2D interface on phones (the layout was drawn for a 1080p monitor).
const MOBILE_UI_SCALE := 1.25
## 3D render resolution on phones (the volumetric explosion is a ray-marcher, so this matters most).
const MOBILE_3D_SCALE := 0.6
## Lowest ray-march quality the auto-quality controller may drop to.
const QUALITY_FLOOR_DESKTOP := 0.4
const QUALITY_FLOOR_MOBILE := 0.18


func _init() -> void:
	is_movie = OS.has_feature("movie")
	is_touch = OS.has_feature("mobile") or OS.has_feature("android") or OS.has_feature("ios") or Args.has("touch")
	if is_touch:
		quality = Quality.LOW       # the auto-quality controller still raises it if the phone keeps up
	_load_data()


func _load_data() -> void:
	var f := FileAccess.open("res://data/bombs.json", FileAccess.READ)
	if f:
		var parsed: Variant = JSON.parse_string(f.get_as_text())
		if parsed is Dictionary:
			bombs = parsed.get("bombs", [])
	else:
		push_error("Cannot open res://data/bombs.json")
	var lf := FileAccess.open("res://data/locale.json", FileAccess.READ)
	if lf:
		var lp: Variant = JSON.parse_string(lf.get_as_text())
		if lp is Dictionary:
			locale = lp
	else:
		push_error("Cannot open res://data/locale.json")


## Historical humidity of the bomb's test site (Pacific atolls / Hiroshima humid, Nevada dry).
func site_humidity(b: Dictionary) -> float:
	return float(b.get("profile", {}).get("site_humidity", 0.35))


func bomb(i: int = -1) -> Dictionary:
	if i < 0:
		i = selected_bomb
	if i < 0 or i >= bombs.size():
		return {}
	return bombs[i]


func tr_key(key: String) -> String:
	var table: Dictionary = locale.get("strings", {})
	if table.has(key):
		var e: Dictionary = table[key]
		return String(e.get(lang, e.get("en", key)))
	return key


func bomb_text(b: Dictionary, field: String) -> String:
	# fields stored as {"ru": "...", "en": "..."}
	var v: Variant = b.get(field, "")
	if v is Dictionary:
		return String(v.get(lang, v.get("en", "")))
	return String(v)


func set_language(l: String) -> void:
	lang = l
	language_changed.emit()


func toggle_language() -> void:
	set_language("en" if lang == "ru" else "ru")


func select_bomb(i: int) -> void:
	selected_bomb = clampi(i, 0, bombs.size() - 1)
	bomb_selected.emit(selected_bomb)


func quality_floor() -> float:
	return QUALITY_FLOOR_MOBILE if is_touch else QUALITY_FLOOR_DESKTOP


func quality_steps_scale() -> float:
	match quality:
		Quality.LOW:
			return 0.5
		Quality.MEDIUM:
			return 0.75
		Quality.HIGH:
			return 1.0
		_:
			return 2.0


## Scene luminance relative to daylight (drives the eye-adaptation response to the flash).
func ambient_level() -> float:
	match tod:
		TimeOfDay.NIGHT:
			return 0.03
		TimeOfDay.PREDAWN:
			return 0.15
	return 1.0
