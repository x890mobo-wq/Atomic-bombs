@echo off
rem Atomic Bombs - export an Android APK (Windows).
rem Needs: Godot 4.7.2 + export templates, JDK 17, Android SDK (platform-tools, build-tools;35.0.1, android-35),
rem and Godot > Editor Settings > Export > Android: "Android SDK Path" and "Java SDK Path".
rem Usage: set GODOT=C:\path\to\Godot_v4.7.2-stable_win64_console.exe  &  build_android.bat
setlocal
cd /d "%~dp0"
if not defined GODOT set "GODOT=Godot_v4.7.2-stable_win64_console.exe"
if not defined KEYSTORE set "KEYSTORE=%CD%\atomic-release.keystore"
if not exist "%KEYSTORE%" (
  echo Creating a signing key: %KEYSTORE%  ^(keep it - updates must be signed with the same key^)
  keytool -genkeypair -v -keystore "%KEYSTORE%" -alias atomic -keyalg RSA -keysize 2048 -validity 10000 -storepass atomic-bombs -keypass atomic-bombs -dname "CN=Atomic Bombs, O=Opus 5.5, C=US"
)
set "GODOT_ANDROID_KEYSTORE_RELEASE_PATH=%KEYSTORE%"
set "GODOT_ANDROID_KEYSTORE_RELEASE_USER=atomic"
set "GODOT_ANDROID_KEYSTORE_RELEASE_PASSWORD=atomic-bombs"
if not exist build mkdir build
"%GODOT%" --headless --path "%CD%" --import
"%GODOT%" --headless --path "%CD%" --export-release "Android" build\AtomicBombs.apk
if errorlevel 1 ( echo BUILD FAILED & exit /b 1 )
echo DONE: %CD%\build\AtomicBombs.apk
endlocal
